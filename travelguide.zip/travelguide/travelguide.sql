-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 22 Jan 2017 pada 17.46
-- Versi Server: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travelguide`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `cart`
--

CREATE TABLE `cart` (
  `CartId` int(11) NOT NULL,
  `tiketId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `critic`
--

CREATE TABLE `critic` (
  `criticId` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `msg` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `critic`
--

INSERT INTO `critic` (`criticId`, `username`, `email`, `msg`) VALUES
(1, 'Vingky', 'vingky123@yahoo.com', 'Aplikasinya keren!'),
(2, 'Vingky', 'vingky123@yahoo.com', 'Perbanyak infonya!'),
(3, 'Astrid Nadia', 'astridnadia@gmail.com', 'Info yang menarik!!');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail`
--

CREATE TABLE `detail` (
  `transactionId` int(11) NOT NULL,
  `headerId` int(11) NOT NULL,
  `tiketId` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `detail`
--

INSERT INTO `detail` (`transactionId`, `headerId`, `tiketId`, `Quantity`) VALUES
(1, 2, 4, 2),
(2, 3, 5, 4),
(3, 6, 4, 1),
(5, 7, 4, 1),
(7, 11, 2, 1),
(8, 11, 3, 1),
(9, 14, 3, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `header`
--

CREATE TABLE `header` (
  `transactionId` int(11) NOT NULL,
  `dateTransaction` date NOT NULL,
  `statusTransaction` varchar(50) NOT NULL,
  `userId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `header`
--

INSERT INTO `header` (`transactionId`, `dateTransaction`, `statusTransaction`, `userId`) VALUES
(6, '2017-01-12', 'Order Complete', 1),
(7, '2017-01-12', 'Waiting for Payment', 1),
(14, '2017-01-22', 'Waiting for Payment', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `ticket`
--

CREATE TABLE `ticket` (
  `tiketId` int(11) NOT NULL,
  `tiketName` varchar(50) NOT NULL,
  `tiketPrice` int(11) NOT NULL,
  `tiketWeight` int(11) NOT NULL,
  `tiketQuantity` int(11) NOT NULL,
  `tiketSpesification` varchar(50) NOT NULL,
  `tiketImage` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `ticket`
--

INSERT INTO `ticket` (`tiketId`, `tiketName`, `tiketPrice`, `tiketWeight`, `tiketQuantity`, `tiketSpesification`, `tiketImage`) VALUES
(2, 'Air Asia', 2500000, 1, 90, 'Bali to Singapura', 'a.png'),
(3, 'Lion Air', 1500000, 1, 97, 'Jakarta to Yogya', 'L.png'),
(4, 'Citilink', 800000, 1, 96, 'Solo to Malang', 'c.png'),
(5, 'Sriwijaya Air', 100000, 1, 96, 'Semarang to Malang', 's.png'),
(6, 'Citilink', 1250000, 1, 80, 'Jakarta to Bali', 'c.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `dob` date NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `fullname`, `username`, `email`, `password`, `phone`, `dob`, `role`) VALUES
(1, 'febrian vingky', 'vingky1', 'vingky@gmail.com', 'vingky1', '081288976907', '1996-02-19', 1),
(2, 'admin', 'admin', 'admin@gmail.com', 'admin', '547457', '1998-09-12', 0),
(3, 'Vinzen FY', 'vinzen12', 'vinzenvinzn@gmail.com', 'vinzen12', '081995550907', '1997-04-01', 1),
(4, 'Astrid Nadia', 'astrid15', 'astridnadia@gmail.com', 'astrid15', '081995550907', '1996-07-08', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`CartId`);

--
-- Indexes for table `critic`
--
ALTER TABLE `critic`
  ADD PRIMARY KEY (`criticId`);

--
-- Indexes for table `detail`
--
ALTER TABLE `detail`
  ADD PRIMARY KEY (`transactionId`);

--
-- Indexes for table `header`
--
ALTER TABLE `header`
  ADD PRIMARY KEY (`transactionId`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`tiketId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `CartId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `critic`
--
ALTER TABLE `critic`
  MODIFY `criticId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `detail`
--
ALTER TABLE `detail`
  MODIFY `transactionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `header`
--
ALTER TABLE `header`
  MODIFY `transactionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `tiketId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
